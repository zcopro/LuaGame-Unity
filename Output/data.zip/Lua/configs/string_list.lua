local string_list = 
{
	[1] = "无法连接服务器，是否重新连接？",
	[2] = "与服务器的连接已断开，是否重新连接？",

	[3] = "是否确定退出游戏?",
}


return string_list
