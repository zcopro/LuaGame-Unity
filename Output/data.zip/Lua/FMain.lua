
require "FPreload"

require "game.FGame"

function main( )
	theGame:Run()
end


